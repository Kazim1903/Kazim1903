<p align="center">
  <img src="./assets/hero.svg" width="100%" alt="Kazım Aydın — Founder and Fintech Technical Project Manager" />
</p>

<p align="center">
  <img src="https://readme-typing-svg.demolab.com?font=Inter&weight=600&size=18&pause=1300&color=7C6CFF&center=true&vCenter=true&width=760&height=36&lines=Building+Fintech%2C+SaaS+and+AI+Products;Leading+Products+from+Strategy+to+Scale;Full-Stack+Development+Background" alt="Animated profile highlights" />
</p>

## About

I’m **Kazım Aydın**, Founder of **Karanix Mühendislik, Teknoloji ve Yazılım A.Ş.** and a **Fintech Technical Project Manager with a Full-Stack Development background**.

I work where product strategy, software architecture and execution meet—leading technical teams and turning ambitious ideas into scalable digital products.

## Product Ecosystem

<p align="center">
  <img src="./assets/ecosystem.svg" width="100%" alt="Karanix product ecosystem" />
</p>

<p align="center">
  <a href="https://ontaba.com"><b>Ontaba</b></a>
  &nbsp;&nbsp;·&nbsp;&nbsp;
  <a href="https://karanpos.com"><b>KaranPOS</b></a>
  &nbsp;&nbsp;·&nbsp;&nbsp;
  <a href="https://nevacortex.com"><b>Neva Cortex</b></a>
  &nbsp;&nbsp;·&nbsp;&nbsp;
  <a href="https://nevaomni.com"><b>Neva Omni</b></a>
  &nbsp;&nbsp;·&nbsp;&nbsp;
  <b>Sorupik</b>
</p>

## Core Focus

| Product Leadership | Technical Delivery | Business Systems |
|:---|:---|:---|
| Product strategy & roadmaps | Architecture & team leadership | Fintech & payment integrations |
| MVP, release & scale | SaaS and AI product delivery | TravelTech, POS, CRM & EdTech |

## Connect

<p align="center">
  <a href="https://karanix.com"><img src="https://img.shields.io/badge/KARANIX-Visit_Website-6C5CE7?style=for-the-badge&logo=googlechrome&logoColor=white" alt="Karanix website" /></a>
  <a href="https://github.com/Kazim1903"><img src="https://img.shields.io/badge/GITHUB-Kazim1903-151B2B?style=for-the-badge&logo=github&logoColor=white" alt="GitHub profile" /></a>
</p>

<p align="center">
  <sub>FROM IDEA → ARCHITECTURE → LAUNCH → SCALE</sub>
</p>
